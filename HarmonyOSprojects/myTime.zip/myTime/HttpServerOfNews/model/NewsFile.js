class NewsFile {
  constructor(id, url, type, newsId) {
    this.id = id;
    this.url = url;
    this.type = type;
    this.newsId = newsId;
  }
}

module.exports = NewsFile;