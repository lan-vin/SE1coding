export { Clock } from "@normalized:N&&&clock/src/main/ets/pages/Clock&1.0.0";
