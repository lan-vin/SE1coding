/**
 * Style constants that can be used by all modules
 */
export default class Constants {
    /**
     * Full width or height.
     */
    static readonly FULL_LENGTH: string = '100%';
    /**
     * Title height.
     */
    static readonly TITLE_WIDTH: string = '80%';
    /**
     * List default width.
     */
    static readonly LIST_DEFAULT_WIDTH: string = '93.3%';
    /**
     * Opacity of default.
     */
    static readonly OPACITY_DEFAULT: number = 1;
    /**
     * Opacity of default.
     */
    static readonly OPACITY_COMPLETED: number = 0.4;
    /**
     * BorderRadius of list item.
     */
    static readonly BORDER_RADIUS: number = 24;
    /**
     * BorderRadius of list item.
     */
    static readonly FONT_WEIGHT: number = 500;
    /**
     * Space of column.
     */
    static readonly COLUMN_SPACE: number = 16;
    static readonly DIALOG_WIDTH: string = "80%";
    static readonly DIALOG_HEIGHT: string = "60%";
    /**
     * agents data.
     */
    static readonly TODO_DATA: Array<string> = [
        "7:30 早起晨练",
        "8:00 准备早餐",
        "11:00 阅读名著",
        "15:00 学习ArkTS",
        "19:45 看剧放松"
    ];
    /**
     * Duration of prompt.
     */
    static DURATION: number = 3000;
    /**
     * The clock time tag.
     */
    static TIME_FLAG: number = 0;
    /**
     * The clock matter tag.
     */
    static MATTER_FLAG: number = 1;
    /**
     * The tag is used to print log.
     */
    static TAG = '[PreferenceModel]';
    /**
     * The key value of the data store.
     */
    static KEY_NAME = 'clock';
    /**
     * The name of the data store.
     */
    static PREFERENCES_NAME = 'clock.db';
}
