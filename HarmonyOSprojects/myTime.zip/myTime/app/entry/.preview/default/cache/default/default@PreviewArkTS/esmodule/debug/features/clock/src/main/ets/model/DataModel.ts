import CommonConstants from "@normalized:N&&&clock/src/main/ets/common/Constant&1.0.0";
/**
 * Saving and manipulating data displayed on the page.
 */
export class DataModel {
    /**
     * Saved Data.
     */
    private tasks: Array<string> = CommonConstants.TODO_DATA;
    /**
     * Get the data.
     */
    getData(): Array<string> {
        return this.tasks;
    }
}
export default new DataModel();
