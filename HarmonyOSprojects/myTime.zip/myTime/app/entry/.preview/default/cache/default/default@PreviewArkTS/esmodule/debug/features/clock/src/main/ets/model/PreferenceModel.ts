import promptAction from "@ohos:promptAction";
import preferences from "@ohos:data.preferences";
import Logger from "@normalized:N&&&clock/src/main/ets/common/Logger&1.0.0";
import CommonConstants from "@normalized:N&&&clock/src/main/ets/common/Constant&1.0.0";
import ClockData from "@normalized:N&&&clock/src/main/ets/model/ClockData&1.0.0";
let context = getContext(this);
let preference: preferences.Preferences;
let preferenceTemp: preferences.Preferences;
/**
 * Preference model.
 *
 * @param ClockData Clock data.
 */
class PreferenceModel {
    private clockData: ClockData = new ClockData();
    /**
     * Read the specified Preferences persistence file and load the data into the Preferences instance.
     */
    async getPreferencesFromStorage() {
        try {
            preference = await preferences.getPreferences(context, CommonConstants.PREFERENCES_NAME);
        }
        catch (err) {
            Logger.error(CommonConstants.TAG, `Failed to get preferences, Cause: ${err}`);
        }
    }
    /**
     * Deletes the specified Preferences persistence file from memory and removes the Preferences instance.
     */
    async deletePreferences() {
        try {
            await preferences.deletePreferences(context, CommonConstants.PREFERENCES_NAME);
        }
        catch (err) {
            Logger.error(CommonConstants.TAG, `Failed to delete preferences, Cause: ${err}`);
        }
        ;
        preference = preferenceTemp;
        this.showToastMessage({ "id": 50331690, "type": 10003, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
    }
    /**
     * Save the data to the Preferences.
     *
     * @param ClockData Clock data.
     */
    async putPreference(clockData: ClockData) {
        if (!preference) {
            await this.getPreferencesFromStorage();
        }
        // The fruit name and fruit quantity data entered by the user are saved to the cached Preference instance.
        try {
            await preference.put(CommonConstants.KEY_NAME, JSON.stringify(clockData));
        }
        catch (err) {
            Logger.error(CommonConstants.TAG, `Failed to put value, Cause: ${err}`);
        }
        // Store the Preference instance in the preference persistence file
        await preference.flush();
    }
    /**
     * Get preference data.
     */
    async getPreference() {
        let fruit = '';
        if (!preference) {
            await this.getPreferencesFromStorage();
        }
        try {
            // fruit = <string> await preference.get(CommonConstants.KEY_NAME, '');
            fruit = (await preference.get(CommonConstants.KEY_NAME, '')).toString();
        }
        catch (err) {
            Logger.error(CommonConstants.TAG, `Failed to get value, Cause: ${err}`);
        }
        // If the data is empty, a message is displayed indicating that data needs to be written.
        if (fruit === '') {
            this.showToastMessage({ "id": 50331688, "type": 10003, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
            return;
        }
        console.log('app.string.read_success_msg');
        return JSON.parse(fruit);
    }
    /**
     * Process the data obtained from the database.
     */
    async getClockData() {
        this.clockData = await this.getPreference();
        return this.clockData;
    }
    /**
     * Verifies that the data entered is not empty.
     *
     * @param ClockData Clock data.
     */
    checkClockData(clockData: ClockData) {
        if (clockData.clockTime === '' || clockData.clockMatter === '') {
            this.showToastMessage({ "id": 50331687, "type": 10003, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
            return true;
        }
        return false;
    }
    /**
     * write data.
     *
     * @param ClockData Clock data.
     */
    async writeData(clockData: ClockData) {
        // Check whether the data is null.
        let isDataNull = this.checkClockData(clockData);
        if (isDataNull) {
            return;
        }
        // The data is inserted into the preferences database if it is not empty.
        this.putPreference(clockData);
        this.showToastMessage({ "id": 50331700, "type": 10003, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
    }
    /**
     * Popup window prompt message.
     *
     * @param message Prompt message.
     */
    showToastMessage(message: Resource) {
        promptAction.showToast({
            message: message,
            duration: CommonConstants.DURATION
        });
    }
    ;
}
export default new PreferenceModel();
