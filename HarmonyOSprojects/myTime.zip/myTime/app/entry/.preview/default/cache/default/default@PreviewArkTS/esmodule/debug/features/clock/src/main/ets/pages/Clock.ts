if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Clock_Params {
    clock?: ClockData;
    totalTasks?: Array<string>;
    ctx?: UIContext;
    contentNode?: ComponentContent<Object>;
}
import Constants from "@normalized:N&&&clock/src/main/ets/common/Constant&1.0.0";
import ClockData from "@normalized:N&&&clock/src/main/ets/model/ClockData&1.0.0";
import ClockItem from "@normalized:N&&&clock/src/main/ets/view/ClockItem&1.0.0";
import TextItem from "@normalized:N&&&clock/src/main/ets/view/TextItem&1.0.0";
import { PromptActionClass } from "@normalized:N&&&clock/src/main/ets/utils/PromptActionClass&1.0.0";
import PreferenceModel from "@normalized:N&&&clock/src/main/ets/model/PreferenceModel&1.0.0";
import { ComponentContent } from "@ohos:arkui.node";
class Params {
    text: string = "";
    clock: ClockData = new ClockData();
    totalTasks: Array<string> = [];
    constructor(clock: ClockData, totalTasks: Array<string>) {
        this.clock = clock;
        this.totalTasks = totalTasks;
    }
}
function buildText(params: Params, parent = null) {
    const __params__ = params;
    (parent ? parent : this).observeComponentCreation2((elmtId, isInitialRender, params = __params__) => {
        Column.create();
        Column.debugLine("features/clock/src/main/ets/pages/Clock.ets(21:3)", "clock");
        Column.backgroundColor('#FFF0F0F0');
        Column.borderRadius("5%");
        Column.padding("5%");
        Column.width(Constants.DIALOG_WIDTH);
        Column.height("auto");
    }, Column);
    {
        (parent ? parent : this).observeComponentCreation2((elmtId, isInitialRender, params = __params__) => {
            if (isInitialRender) {
                let componentCall = new 
                // 时间输入框
                TextItem(parent ? parent : this, {
                    textResource: { "id": 50331698, "type": 10003, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" },
                    placeholderResource: { "id": 50331697, "type": 10003, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" },
                    textFlag: Constants.TIME_FLAG,
                    clock: params.clock,
                    textInputCallBack: (value: string) => {
                        // 更新输入的时间
                        params.clock.clockTime = value; // 直接更新 clock 对象中的时间
                    }
                }, undefined, elmtId, () => { }, { page: "features/clock/src/main/ets/pages/Clock.ets", line: 23, col: 5 });
                ViewPU.create(componentCall);
                let paramsLambda = () => {
                    return {
                        textResource: { "id": 50331698, "type": 10003, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" },
                        placeholderResource: { "id": 50331697, "type": 10003, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" },
                        textFlag: Constants.TIME_FLAG,
                        clock: params.clock,
                        textInputCallBack: (value: string) => {
                            // 更新输入的时间
                            params.clock.clockTime = value; // 直接更新 clock 对象中的时间
                        }
                    };
                };
                componentCall.paramsGenerator_ = paramsLambda;
            }
            else {
                (parent ? parent : this).updateStateVarsOfChildByElmtId(elmtId, {});
            }
        }, { name: "TextItem" });
    }
    {
        (parent ? parent : this).observeComponentCreation2((elmtId, isInitialRender, params = __params__) => {
            if (isInitialRender) {
                let componentCall = new 
                // 事件输入框
                TextItem(parent ? parent : this, {
                    textResource: { "id": 50331694, "type": 10003, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" },
                    placeholderResource: { "id": 50331693, "type": 10003, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" },
                    textFlag: Constants.MATTER_FLAG,
                    clock: params.clock,
                    textInputCallBack: (value: string) => {
                        // 更新输入的事件
                        params.clock.clockMatter = value; // 直接更新 clock 对象中的事件内容
                    }
                }, undefined, elmtId, () => { }, { page: "features/clock/src/main/ets/pages/Clock.ets", line: 35, col: 5 });
                ViewPU.create(componentCall);
                let paramsLambda = () => {
                    return {
                        textResource: { "id": 50331694, "type": 10003, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" },
                        placeholderResource: { "id": 50331693, "type": 10003, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" },
                        textFlag: Constants.MATTER_FLAG,
                        clock: params.clock,
                        textInputCallBack: (value: string) => {
                            // 更新输入的事件
                            params.clock.clockMatter = value; // 直接更新 clock 对象中的事件内容
                        }
                    };
                };
                componentCall.paramsGenerator_ = paramsLambda;
            }
            else {
                (parent ? parent : this).updateStateVarsOfChildByElmtId(elmtId, {});
            }
        }, { name: "TextItem" });
    }
    (parent ? parent : this).observeComponentCreation2((elmtId, isInitialRender, params = __params__) => {
        // 按钮横向排列
        Row.create();
        Row.debugLine("features/clock/src/main/ets/pages/Clock.ets(47:5)", "clock");
    }, Row);
    (parent ? parent : this).observeComponentCreation2((elmtId, isInitialRender, params = __params__) => {
        Button.createWithLabel('确认');
        Button.debugLine("features/clock/src/main/ets/pages/Clock.ets(48:7)", "clock");
        Button.onClick(async () => {
            if (params.clock.clockTime) {
                const clockData = new ClockData();
                clockData.clockTime = params.clock.clockTime;
                clockData.clockMatter = params.clock.clockMatter;
                // 更新 totalTasks
                params.totalTasks.push(`${clockData.clockTime} ${clockData.clockMatter}`);
                // 保存数据
                await PreferenceModel.writeData(clockData);
                // 刷新页面
                params.clock.clockTime = "";
                params.clock.clockMatter = "";
                PromptActionClass.closeDialog(params);
            }
        });
        Button.width("40%");
        Button.margin({ right: "13%" });
    }, Button);
    Button.pop();
    (parent ? parent : this).observeComponentCreation2((elmtId, isInitialRender, params = __params__) => {
        Button.createWithLabel('取消');
        Button.debugLine("features/clock/src/main/ets/pages/Clock.ets(69:7)", "clock");
        Button.onClick(() => {
            params.clock.clockTime = "";
            params.clock.clockMatter = "";
            PromptActionClass.closeDialog(params);
        });
        Button.width("40%");
    }, Button);
    Button.pop();
    // 按钮横向排列
    Row.pop();
    Column.pop();
}
export class Clock extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__clock = new ObservedPropertyObjectPU(new ClockData(), this, "clock");
        this.__totalTasks = new ObservedPropertyObjectPU([], this, "totalTasks");
        this.ctx = this.getUIContext();
        this.contentNode = new ComponentContent(this.ctx, wrapBuilder(buildText), new Params(this.clock, this.totalTasks));
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Clock_Params) {
        if (params.clock !== undefined) {
            this.clock = params.clock;
        }
        if (params.totalTasks !== undefined) {
            this.totalTasks = params.totalTasks;
        }
        if (params.ctx !== undefined) {
            this.ctx = params.ctx;
        }
        if (params.contentNode !== undefined) {
            this.contentNode = params.contentNode;
        }
    }
    updateStateVars(params: Clock_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__clock.purgeDependencyOnElmtId(rmElmtId);
        this.__totalTasks.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__clock.aboutToBeDeleted();
        this.__totalTasks.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __clock: ObservedPropertyObjectPU<ClockData>;
    get clock() {
        return this.__clock.get();
    }
    set clock(newValue: ClockData) {
        this.__clock.set(newValue);
    }
    private __totalTasks: ObservedPropertyObjectPU<Array<string>>;
    get totalTasks() {
        return this.__totalTasks.get();
    }
    set totalTasks(newValue: Array<string>) {
        this.__totalTasks.set(newValue);
    }
    //private userInput: string = ""; // 用于存储用户输入的时间
    private ctx: UIContext;
    private contentNode: ComponentContent<Object>;
    async aboutToAppear() {
        this.setupAlarmChecker(); // 设置闹钟检查
        // Get the lightweight storage db file from memory.
        console.log("get clock data...");
        await PreferenceModel.getPreferencesFromStorage();
        // Get the key value with the key name clock from the lightweight storage db file.
        PreferenceModel.getClockData().then((resultData: ClockData) => {
            // if (resultData) {
            //   this.totalTasks = resultData;
            // }
            console.log("get clock data success!");
        });
        //设置弹窗数据
        PromptActionClass.setContext(this.ctx);
        PromptActionClass.setContentNode(this.contentNode);
        PromptActionClass.setOptions(new Params(this.clock, this.totalTasks));
    }
    setupAlarmChecker() {
        setInterval(() => {
            const currentTime = this.getCurrentTime(); // 获取当前时间
            this.checkAlarms(currentTime);
        }, 60000); // 每分钟检查一次
    }
    getCurrentTime(): string {
        const date = new Date();
        return `${date.getHours()}:${date.getMinutes()}`; // 返回当前时间的字符串格式
    }
    checkAlarms(currentTime: string) {
        this.totalTasks.forEach((task: string) => {
            const time = task.split(' ')[0];
            const matter = task.split(' ')[1];
            if (time === currentTime) {
                AlertDialog.show({
                    title: '闹钟时间已到',
                    subtitle: time,
                    message: matter,
                    autoCancel: true,
                    alignment: DialogAlignment.Bottom,
                    gridCount: 4,
                    offset: { dx: 0, dy: -20 },
                    primaryButton: {
                        value: '稍后再响',
                        action: () => {
                            console.info('Callback when the first button is clicked');
                        }
                    },
                    secondaryButton: {
                        enabled: true,
                        defaultFocus: true,
                        style: DialogButtonStyle.HIGHLIGHT,
                        value: '关闭闹钟',
                        action: () => {
                            console.info('Callback when the second button is clicked');
                        }
                    }
                });
            }
        });
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: Constants.COLUMN_SPACE });
            Column.debugLine("features/clock/src/main/ets/pages/Clock.ets(158:5)", "clock");
            Column.width(Constants.FULL_LENGTH);
            Column.height(Constants.FULL_LENGTH);
            Column.backgroundColor({ "id": 50331680, "type": 10001, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 50331671, "type": 10003, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
            Text.debugLine("features/clock/src/main/ets/pages/Clock.ets(159:7)", "clock");
            Text.fontSize({ "id": 50331677, "type": 10002, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
            Text.fontWeight(FontWeight.Bold);
            Text.lineHeight({ "id": 50331676, "type": 10002, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
            Text.width(Constants.TITLE_WIDTH);
            Text.margin({
                top: { "id": 50331679, "type": 10002, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" },
                bottom: { "id": 50331678, "type": 10002, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" }
            });
            Text.textAlign(TextAlign.Start);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 添加按钮
            Button.createWithLabel({ "id": 50331685, "type": 10003, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
            Button.debugLine("features/clock/src/main/ets/pages/Clock.ets(171:7)", "clock");
            // 添加按钮
            Button.margin({ top: 30 });
            // 添加按钮
            Button.onClick(() => {
                this.contentNode = new ComponentContent(this.ctx, wrapBuilder(buildText), new Params(this.clock, this.totalTasks));
                PromptActionClass.openDialog(this.contentNode);
            });
        }, Button);
        // 添加按钮
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new ClockItem(this, { content: item }, undefined, elmtId, () => { }, { page: "features/clock/src/main/ets/pages/Clock.ets", line: 179, col: 9 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {
                                    content: item
                                };
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                    }, { name: "ClockItem" });
                }
            };
            this.forEachUpdateFunction(elmtId, this.totalTasks, forEachItemGenFunction, (item: string) => JSON.stringify(item), false, false);
        }, ForEach);
        ForEach.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
