export function showDialog(message: string) {
    // 假设这是一个简单的弹窗实现
    console.log(message); // 这里可以替换为实际的弹窗实现
}
