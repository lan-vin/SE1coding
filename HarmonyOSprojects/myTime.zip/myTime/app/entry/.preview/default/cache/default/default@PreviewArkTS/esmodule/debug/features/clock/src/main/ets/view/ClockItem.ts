if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ClockItem_Params {
    content?: string;
    isComplete?: boolean;
}
import Constants from "@normalized:N&&&clock/src/main/ets/common/Constant&1.0.0";
export default class ClockItem extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.content = undefined;
        this.__isComplete = new ObservedPropertySimplePU(false, this, "isComplete");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ClockItem_Params) {
        if (params.content !== undefined) {
            this.content = params.content;
        }
        if (params.isComplete !== undefined) {
            this.isComplete = params.isComplete;
        }
    }
    updateStateVars(params: ClockItem_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__isComplete.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__isComplete.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private content?: string;
    private __isComplete: ObservedPropertySimplePU<boolean>;
    get isComplete() {
        return this.__isComplete.get();
    }
    set isComplete(newValue: boolean) {
        this.__isComplete.set(newValue);
    }
    labelIcon(icon: Resource, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(icon);
            Image.debugLine("features/clock/src/main/ets/view/ClockItem.ets(9:5)", "clock");
            Image.objectFit(ImageFit.Contain);
            Image.width({ "id": 50331673, "type": 10002, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
            Image.height({ "id": 50331673, "type": 10002, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
            Image.margin({ "id": 50331672, "type": 10002, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
        }, Image);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("features/clock/src/main/ets/view/ClockItem.ets(17:5)", "clock");
            Row.borderRadius(Constants.BORDER_RADIUS);
            Row.backgroundColor({ "id": 50331659, "type": 10001, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
            Row.width(Constants.LIST_DEFAULT_WIDTH);
            Row.height({ "id": 50331675, "type": 10002, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
            Row.onClick(() => {
                this.isComplete = !this.isComplete;
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isComplete) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.labelIcon.bind(this)({ "id": 50331666, "type": 20000, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.labelIcon.bind(this)({ "id": 50331658, "type": 20000, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.content);
            Text.debugLine("features/clock/src/main/ets/view/ClockItem.ets(24:7)", "clock");
            Text.fontSize({ "id": 50331674, "type": 10002, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
            Text.fontWeight(Constants.FONT_WEIGHT);
            Text.opacity(this.isComplete ? Constants.OPACITY_COMPLETED : Constants.OPACITY_DEFAULT);
            Text.decoration({ type: this.isComplete ? TextDecorationType.LineThrough : TextDecorationType.None });
        }, Text);
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
