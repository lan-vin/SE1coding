if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface TextItem_Params {
    clock?: ClockData;
    textResource?: Resource;
    placeholderResource?: Resource;
    textFlag?: number;
    textInputCallBack?;
    marginBottom?: string;
    marginTop?: string;
    textInputType?: InputType;
}
import StyleConstants from "@normalized:N&&&clock/src/main/ets/common/StyleConstants&1.0.0";
import Constants from "@normalized:N&&&clock/src/main/ets/common/Constant&1.0.0";
import ClockData from "@normalized:N&&&clock/src/main/ets/model/ClockData&1.0.0";
export default class TextItem extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.clock = new ClockData();
        this.textResource = { "id": 50331691, "type": 10003, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" };
        this.placeholderResource = { "id": 50331691, "type": 10003, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" };
        this.textFlag = 0;
        this.textInputCallBack = (value: string) => { };
        this.marginBottom = '';
        this.marginTop = '';
        this.textInputType = InputType.Normal;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: TextItem_Params) {
        if (params.clock !== undefined) {
            this.clock = params.clock;
        }
        if (params.textResource !== undefined) {
            this.textResource = params.textResource;
        }
        if (params.placeholderResource !== undefined) {
            this.placeholderResource = params.placeholderResource;
        }
        if (params.textFlag !== undefined) {
            this.textFlag = params.textFlag;
        }
        if (params.textInputCallBack !== undefined) {
            this.textInputCallBack = params.textInputCallBack;
        }
        if (params.marginBottom !== undefined) {
            this.marginBottom = params.marginBottom;
        }
        if (params.marginTop !== undefined) {
            this.marginTop = params.marginTop;
        }
        if (params.textInputType !== undefined) {
            this.textInputType = params.textInputType;
        }
    }
    updateStateVars(params: TextItem_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private clock: ClockData;
    private textResource: Resource;
    private placeholderResource: Resource;
    private textFlag: number;
    private textInputCallBack;
    private marginBottom: string;
    private marginTop: string;
    private textInputType: InputType;
    aboutToAppear() {
        if (this.textFlag === Constants.TIME_FLAG) {
            // clock time text input.
            this.marginTop = StyleConstants.MARGIN_TOP;
        }
        else {
            // clock matter text input.
        }
        this.marginBottom = StyleConstants.MARGIN_BOTTOM_SMALL;
        this.textInputType = InputType.Normal;
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("features/clock/src/main/ets/view/TextItem.ets(46:5)", "clock");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.textResource);
            Text.debugLine("features/clock/src/main/ets/view/TextItem.ets(47:7)", "clock");
            Text.fontSize(StyleConstants.FONT_SIZE);
            Text.height("auto");
            Text.width(StyleConstants.FULL_PERCENT);
            Text.fontColor({ "id": 50331704, "type": 10001, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
            Text.letterSpacing(StyleConstants.LETTER_SPACING);
            Text.fontWeight(StyleConstants.FONT_WEIGHT);
            Text.margin({
                bottom: StyleConstants.TEXT_MARGIN_BOTTOM,
                left: StyleConstants.TEXT_MARGIN_LEFT,
            });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({
                placeholder: this.placeholderResource,
                text: this.textFlag === 0 ? (this.clock.clockTime) : (this.clock.clockMatter)
            });
            TextInput.debugLine("features/clock/src/main/ets/view/TextItem.ets(59:7)", "clock");
            TextInput.placeholderFont({ size: StyleConstants.FONT_SIZE, weight: StyleConstants.FONT_WEIGHT });
            TextInput.placeholderColor({ "id": 50331703, "type": 10001, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
            TextInput.caretColor(Color.Blue);
            TextInput.type(this.textInputType);
            TextInput.height("auto");
            TextInput.width(StyleConstants.TEXT_INPUT_WIDTH);
            TextInput.margin({ bottom: this.marginBottom });
            TextInput.fontSize(StyleConstants.FONT_SIZE);
            TextInput.fontColor({ "id": 50331704, "type": 10001, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
            TextInput.fontWeight(StyleConstants.FONT_WEIGHT);
            TextInput.backgroundColor({ "id": 50331705, "type": 10001, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
            TextInput.onChange((value: string) => {
                this.textInputCallBack(value);
            });
        }, TextInput);
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
