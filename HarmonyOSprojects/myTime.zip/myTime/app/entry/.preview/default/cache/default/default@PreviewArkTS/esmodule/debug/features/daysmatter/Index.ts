export { DaysMatter } from "@normalized:N&&&daysmatter/src/main/ets/pages/DaysMatter&1.0.0";
