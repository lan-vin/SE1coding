if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface DaysMatter_Params {
}
import TabBar from "@normalized:N&&&daysmatter/src/main/ets/view/TabBar&1.0.0";
import { CommonConstant as Const } from "@normalized:N&&&daysmatter/src/main/ets/common/constant/CommonConstant&1.0.0";
export class DaysMatter extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: DaysMatter_Params) {
    }
    updateStateVars(params: DaysMatter_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("features/daysmatter/src/main/ets/pages/DaysMatter.ets(11:5)", "daysmatter");
            Column.width(Const.FULL_WIDTH);
            Column.backgroundColor({ "id": 50331725, "type": 10001, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new TabBar(this, {}, undefined, elmtId, () => { }, { page: "features/daysmatter/src/main/ets/pages/DaysMatter.ets", line: 12, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {};
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "TabBar" });
        }
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
