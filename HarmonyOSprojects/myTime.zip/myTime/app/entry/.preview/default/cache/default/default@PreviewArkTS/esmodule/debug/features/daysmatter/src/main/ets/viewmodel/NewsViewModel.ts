import { CommonConstant as Const } from "@normalized:N&&&daysmatter/src/main/ets/common/constant/CommonConstant&1.0.0";
import type { NewsData } from './NewsData';
import type NewsTypeModel from './NewsTypeModel';
import { httpRequestGet } from "@normalized:N&&&daysmatter/src/main/ets/common/utils/HttpUtil&1.0.0";
import Logger from "@normalized:N&&&daysmatter/src/main/ets/common/utils/Logger&1.0.0";
import type ResponseResult from './ResponseResult';
class NewsViewModel {
    /**
     * Get news type list from server.
     *
     * @return NewsTypeBean[] newsTypeList
     */
    getNewsTypeList(): Promise<NewsTypeModel[]> {
        return new Promise((resolve: Function, reject: Function) => {
            let url = `${Const.SERVER}/${Const.GET_NEWS_TYPE}`;
            httpRequestGet(url).then((data: ResponseResult) => {
                if (data.code === Const.SERVER_CODE_SUCCESS) {
                    resolve(data.data);
                }
                else {
                    reject(Const.TabBars_DEFAULT_NEWS_TYPES);
                }
            }).catch(() => {
                reject(Const.TabBars_DEFAULT_NEWS_TYPES);
            });
        });
    }
    /**
     * Get default news type list.
     *
     * @return NewsTypeBean[] newsTypeList
     */
    getDefaultTypeList(): NewsTypeModel[] {
        return Const.TabBars_DEFAULT_NEWS_TYPES;
    }
    /**
     * Get news type list from server.
     *
     * @return NewsData[] newsDataList
     */
    getNewsList(currentPage: number, pageSize: number, path: string): Promise<NewsData[]> {
        return new Promise(async (resolve: Function, reject: Function) => {
            let url = `${Const.SERVER}/${path}`;
            url += '?currentPage=' + currentPage + '&pageSize=' + pageSize;
            httpRequestGet(url).then((data: ResponseResult) => {
                if (data.code === Const.SERVER_CODE_SUCCESS) {
                    resolve(data.data);
                }
                else {
                    Logger.error('getNewsList failed', JSON.stringify(data));
                    reject({ "id": 50331710, "type": 10003, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
                }
            }).catch((err: Error) => {
                Logger.error('getNewsList failed', JSON.stringify(err));
                reject({ "id": 50331709, "type": 10003, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
            });
        });
    }
}
let newsViewModel = new NewsViewModel();
export default newsViewModel as NewsViewModel;
