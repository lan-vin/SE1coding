if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Weather_Params {
    controller?: webview.WebviewController;
    buttonName?: Resource;
    webVisibility?: Visibility;
    webSrc?: string;
}
import webview from "@ohos:web.webview";
import StyleConstant from "@normalized:N&&&weather/src/main/ets/common/constant/StyleConstant&1.0.0";
import CommonConstant from "@normalized:N&&&weather/src/main/ets/common/constant/CommonConstants&1.0.0";
export class Weather extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.controller = new webview.WebviewController();
        this.__buttonName = new ObservedPropertyObjectPU({ "id": 50331745, "type": 10003, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" }, this, "buttonName");
        this.__webVisibility = new ObservedPropertySimplePU(Visibility.Visible, this, "webVisibility");
        this.__webSrc = new ObservedPropertySimplePU(CommonConstant.SERVER, this, "webSrc");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Weather_Params) {
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.buttonName !== undefined) {
            this.buttonName = params.buttonName;
        }
        if (params.webVisibility !== undefined) {
            this.webVisibility = params.webVisibility;
        }
        if (params.webSrc !== undefined) {
            this.webSrc = params.webSrc;
        }
    }
    updateStateVars(params: Weather_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__buttonName.purgeDependencyOnElmtId(rmElmtId);
        this.__webVisibility.purgeDependencyOnElmtId(rmElmtId);
        this.__webSrc.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__buttonName.aboutToBeDeleted();
        this.__webVisibility.aboutToBeDeleted();
        this.__webSrc.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private controller: webview.WebviewController;
    private __buttonName: ObservedPropertyObjectPU<Resource>;
    get buttonName() {
        return this.__buttonName.get();
    }
    set buttonName(newValue: Resource) {
        this.__buttonName.set(newValue);
    }
    private __webVisibility: ObservedPropertySimplePU<Visibility>;
    get webVisibility() {
        return this.__webVisibility.get();
    }
    set webVisibility(newValue: Visibility) {
        this.__webVisibility.set(newValue);
    }
    private __webSrc: ObservedPropertySimplePU<string>;
    get webSrc() {
        return this.__webSrc.get();
    }
    set webSrc(newValue: string) {
        this.__webSrc.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("features/weather/src/main/ets/pages/Weather.ets(13:5)", "weather");
            Column.width(StyleConstant.FULL_WIDTH);
            Column.height("auto");
            Column.backgroundImage({ "id": 50331747, "type": 20000, params: [ImageRepeat.NoRepeat], "bundleName": "com.example.mytime", "moduleName": "entry" });
            Column.backgroundImageSize(ImageSize.Cover);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("features/weather/src/main/ets/pages/Weather.ets(14:7)", "weather");
            Row.margin({
                top: { "id": 50331735, "type": 10002, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" },
                left: { "id": 50331735, "type": 10002, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" },
                right: { "id": 50331735, "type": 10002, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" }
            });
            Row.height("auto");
            Row.backgroundColor(Color.White);
            Row.borderRadius({ "id": 50331731, "type": 10002, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
            Row.padding({
                left: { "id": 50331736, "type": 10002, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" },
                right: { "id": 50331736, "type": 10002, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" }
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 50331748, "type": 20000, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
            Image.debugLine("features/weather/src/main/ets/pages/Weather.ets(15:9)", "weather");
            Image.height({ "id": 50331738, "type": 10002, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
            Image.width({ "id": 50331739, "type": 10002, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: { "id": 50331743, "type": 10003, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" }, text: this.webSrc });
            TextInput.debugLine("features/weather/src/main/ets/pages/Weather.ets(18:9)", "weather");
            TextInput.height({ "id": 50331740, "type": 10002, params: [], "bundleName": "com.example.mytime", "moduleName": "entry" });
            TextInput.layoutWeight(1);
            TextInput.backgroundColor(Color.White);
            TextInput.onChange((value: string) => {
                this.webSrc = value;
            });
        }, TextInput);
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Web.create({ src: this.webSrc, controller: this.controller });
            Web.debugLine("features/weather/src/main/ets/pages/Weather.ets(38:7)", "weather");
            Web.zoomAccess(true);
        }, Web);
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
